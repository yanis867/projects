import javax.swing.*;
import org.jfree.chart.*;
import org.jfree.chart.plot.*;
import org.jfree.data.category.*;
import java.awt.*;
import javax.swing.table.TableModel;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.jfree.chart.renderer.category.BarRenderer;

public class DataGraphWindow extends JFrame {
    private JLabel dateTime;

    public DataGraphWindow(TableModel tableModel) {
        setTitle("Sahtec - Data Graph");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(942, 627);
        setLocationRelativeTo(null);
        setResizable(false);
        setLayout(null);

        // Set Background
        JLabel background = new JLabel(new ImageIcon(getClass().getResource("/Backgroundimg2.png")));
        background.setBounds(0, 0, 942, 627);
        background.setOpaque(false);
        add(background);

        // Add Logo
        JLabel logo = new JLabel(new ImageIcon(new ImageIcon(getClass().getResource("/logo2.png"))
                .getImage()
                .getScaledInstance(170, 58, Image.SCALE_SMOOTH)));
        logo.setBounds(20, 10, 170, 58);
        background.add(logo);

        // Add Date and Time
        dateTime = new JLabel();
        dateTime.setFont(new Font("Arial", Font.BOLD, 14));
        dateTime.setForeground(Color.BLACK);
        dateTime.setBounds(700, 10, 230, 30);
        updateDateTime();
        background.add(dateTime);

        // Create datasets for the graphs
        DefaultCategoryDataset weightTempDataset = new DefaultCategoryDataset();
        DefaultCategoryDataset bloodPressureDataset = new DefaultCategoryDataset();

        // Populate datasets
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            try {
                String day = tableModel.getValueAt(i, 0).toString(); // Day label

                // Remove units before parsing
                String weight = tableModel.getValueAt(i, 1).toString().replace(" KG", "").trim();
                String temp = tableModel.getValueAt(i, 2).toString().replace("°C", "").trim();
                String bp = tableModel.getValueAt(i, 3).toString().replace(" bpm", "").trim(); // Blood pressure

                String[] tension = bp.split("/"); // Split systolic/diastolic

                // Parse weight, temperature, and blood pressure values
                weightTempDataset.addValue(Double.parseDouble(weight), "Weight", day);
                weightTempDataset.addValue(Double.parseDouble(temp), "Temperature", day);

                // Add systolic and diastolic to the blood pressure dataset
                bloodPressureDataset.addValue(Double.parseDouble(tension[0].trim()), "Systolic", day);
                bloodPressureDataset.addValue(Double.parseDouble(tension[1].trim()), "Diastolic", day);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this,
                        "Error parsing data for graph: " + ex.getMessage(),
                        "Data Parsing Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        }

        // Create weight/temp graph
        JFreeChart weightTempChart = ChartFactory.createBarChart(
                "Weight and Temperature", "Day", "Value", weightTempDataset);
        CategoryPlot plot1 = weightTempChart.getCategoryPlot();
        BarRenderer renderer1 = (BarRenderer) plot1.getRenderer();
        renderer1.setSeriesPaint(0, new Color(63, 63, 63)); // Weight color
        renderer1.setSeriesPaint(1, new Color(38, 126, 53)); // Temperature color

        // Create blood pressure graph
        JFreeChart bloodPressureChart = ChartFactory.createBarChart(
                "Blood Pressure", "Day", "Pressure (mmHg)", bloodPressureDataset);
        CategoryPlot plot2 = bloodPressureChart.getCategoryPlot();
        BarRenderer renderer2 = (BarRenderer) plot2.getRenderer();
        renderer2.setSeriesPaint(0, new Color(38, 126, 53)); // Systolic color
        renderer2.setSeriesPaint(1, new Color(63, 63, 63)); // Diastolic color

        // Add both charts to a panel
        JPanel chartPanel = new JPanel(new GridLayout(1, 2));
        chartPanel.add(new ChartPanel(weightTempChart));
        chartPanel.add(new ChartPanel(bloodPressureChart));
        chartPanel.setBounds(50, 150, 850, 400);
        background.add(chartPanel); 

        setVisible(true);
    }

    private void updateDateTime() {
        Timer timer = new Timer(1000, e -> {
            SimpleDateFormat sdf = new SimpleDateFormat("EEEE dd/MM/yyyy  HH:mm:ss");
            dateTime.setText(sdf.format(new Date()));
        });
        timer.start();
    }
}